# wissen

[![Join the chat at https://gitter.im/Seiferxx/wissen](https://badges.gitter.im/Seiferxx/wissen.svg)](https://gitter.im/Seiferxx/wissen?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
Spring boot web mvc application, Flashcards repository

__TODO__
* Enable security
