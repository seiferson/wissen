package com.seifernet.wissen.util;

public class URL {
	
}
