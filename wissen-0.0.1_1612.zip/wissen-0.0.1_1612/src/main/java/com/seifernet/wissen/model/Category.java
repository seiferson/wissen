package com.seifernet.wissen.model;

public class Category {

	
}
