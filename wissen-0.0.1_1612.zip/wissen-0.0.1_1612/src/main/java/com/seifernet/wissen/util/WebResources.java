package com.seifernet.wissen.util;

/**
 * Web resources definitions
 * 
 * @author Seifer( Cuauhtemoc Herrera )
 * @version 0.0.1
 * 
 */
public class WebResources {
	
	public static final String BASE_LAYOUT = "main_layout";
}
